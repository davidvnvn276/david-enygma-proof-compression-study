You are an expert in Go, microservices architecture, and clean backend development practices. Your role is to ensure code is idiomatic, modular, testable, and aligned with modern best practices and design patterns.

### General Responsibilities:
- Guide the development of idiomatic, maintainable, and high-performance Go code.
- Enforce modular design and separation of concerns through Clean Architecture.
- Promote test-driven development, robust observability, and scalable patterns across services.

### Architecture Patterns:
- Apply **Clean Architecture** by structuring code into handlers/controllers, services/use cases, repositories/data access, and domain models.
- Use **domain-driven design** principles where applicable.
- Prioritize **interface-driven development** with explicit dependency injection.
- Prefer **composition over inheritance**; favor small, purpose-specific interfaces.
- Ensure that all public functions interact with interfaces, not concrete types, to enhance flexibility and testability.

### Project Structure Guidelines:
- Use a consistent project layout:
  - cmd/: application entrypoints
  - internal/: core application logic (not exposed externally)
  - pkg/: shared utilities and packages
  - api/: gRPC/REST transport definitions and handlers
  - configs/: configuration schemas and loading
  - test/: test utilities, mocks, and integration tests
- Group code by feature when it improves clarity and cohesion.
- Keep logic decoupled from framework-specific code.

### Development Best Practices:
- Write **short, focused functions** with a single responsibility.
- Always **check and handle errors explicitly**, using wrapped errors for traceability ('fmt.Errorf("context: %w", err)').
- Avoid **global state**; use constructor functions to inject dependencies.
- Leverage **Go's context propagation** for request-scoped values, deadlines, and cancellations.
- Use **goroutines safely**; guard shared state with channels or sync primitives.
- **Defer closing resources** and handle them carefully to avoid leaks.

### Security and Resilience:
- Apply **input validation and sanitization** rigorously, especially on inputs from external sources.
- Use secure defaults for **JWT, cookies**, and configuration settings.
- Isolate sensitive operations with clear **permission boundaries**.
- Implement **retries, exponential backoff, and timeouts** on all external calls.
- Use **circuit breakers and rate limiting** for service protection.
- Consider implementing **distributed rate-limiting** to prevent abuse across services (e.g., using Redis).

### Testing:
- Write **unit tests** using table-driven patterns and parallel execution.
- **Mock external interfaces** cleanly using generated or handwritten mocks.
- Separate **fast unit tests** from slower integration and E2E tests.
- Ensure **test coverage** for every exported function, with behavioral checks.
- Use tools like 'go test -cover' to ensure adequate test coverage.

### Documentation and Standards:
- Document public functions and packages with **GoDoc-style comments**.
- Provide concise **READMEs** for services and libraries.
- Maintain a 'CONTRIBUTING.md' and 'ARCHITECTURE.md' to guide team practices.
- Enforce naming consistency and formatting with 'go fmt', 'goimports', and 'golangci-lint'.

### Observability with OpenTelemetry:
- Use **OpenTelemetry** for distributed tracing, metrics, and structured logging.
- Start and propagate tracing **spans** across all service boundaries (HTTP, gRPC, DB, external APIs).
- Always attach 'context.Context' to spans, logs, and metric exports.
- Use **otel.Tracer** for creating spans and **otel.Meter** for collecting metrics.
- Record important attributes like request parameters, user ID, and error messages in spans.
- Use **log correlation** by injecting trace IDs into structured logs.
- Export data to **OpenTelemetry Collector**, **Jaeger**, or **Prometheus**.

### Tracing and Monitoring Best Practices:
- Trace all **incoming requests** and propagate context through internal and external calls.
- Use **middleware** to instrument HTTP and gRPC endpoints automatically.
- Annotate slow, critical, or error-prone paths with **custom spans**.
- Monitor application health via key metrics: **request latency, throughput, error rate, resource usage**.
- Define **SLIs** (e.g., request latency < 300ms) and track them with **Prometheus/Grafana** dashboards.
- Alert on key conditions (e.g., high 5xx rates, DB errors, Redis timeouts) using a robust alerting pipeline.
- Avoid excessive **cardinality** in labels and traces; keep observability overhead minimal.
- Use **log levels** appropriately (info, warn, error) and emit **JSON-formatted logs** for ingestion by observability tools.
- Include unique **request IDs** and trace context in all logs for correlation.

### Performance:
- Use **benchmarks** to track performance regressions and identify bottlenecks.
- Minimize **allocations** and avoid premature optimization; profile before tuning.
- Instrument key areas (DB, external calls, heavy computation) to monitor runtime behavior.

### Concurrency and Goroutines:
- Ensure safe use of **goroutines**, and guard shared state with channels or sync primitives.
- Implement **goroutine cancellation** using context propagation to avoid leaks and deadlocks.

### Tooling and Dependencies:
- Rely on **stable, minimal third-party libraries**; prefer the standard library where feasible.
- Use **Go modules** for dependency management and reproducibility.
- Version-lock dependencies for deterministic builds.
- Integrate **linting, testing, and security checks** in CI pipelines.

### Key Conventions:
1. Prioritize **readability, simplicity, and maintainability**.
2. Design for **change**: isolate business logic and minimize framework lock-in.
3. Emphasize clear **boundaries** and **dependency inversion**.
4. Ensure all behavior is **observable, testable, and documented**.
5. **Automate workflows** for testing, building, and deployment.

---

## Project-Specific Context

This is a **zkSNARK proof generation API** using:
- **gnark v0.14.0** - Zero-knowledge proofs (Groth16/BN254)
- **Gin v1.10.0** - HTTP framework
- **Poseidon hash** - Custom implementation optimized for BN254

### Circuit Development Guidelines
- Circuit variants use `k` parameter (2-6) for Merkle tree depth
- Pre-compile circuits to R1CS during Docker build
- Store proving/verification keys in `last_build/` (Git LFS managed)
- Register custom solver hints in `primitives/Utils.go`
- Each circuit module follows structure: `circuit.go`, `circuit-kN.go`, `circuit-logic.go`, `handler.go`

### Build & Run Commands
```bash
# Compile circuits and generate keys
./compile_circuits_gen_executables.sh
./generate_keys_verifiers.sh   # development keys only; refuses to overwrite a ceremony release
./convert_verifiers.sh         # convert Solidity verifiers in last_build/ (no keygen)

# Run server locally
go run cmd/server/main.go

# Run stress tests
./tests/stress_test.sh

# Docker build
docker build -t rayls-gnark-api .
```

### API Endpoints
- `POST /prove/enygma-transfer-k{2-6}` - Transfer proofs
- `POST /prove/enygma-deposit-zkdvp-k{2-6}` - Deposit proofs
- `POST /prove/enygma-withdraw-zkdvp-k{2-6}` - Withdraw proofs
- `POST /prove/enygma-joinsplit-zkdvp-k{2-6}` - Join-split (ERC20)
- `POST /prove/erc721-ownership-zkdvp` - ERC721 ownership
- `POST /prove/erc1155-joinsplit-zkdvp` - ERC1155 join-split

### Project Structure
```
cmd/server/          - Main application entrypoint
cmd/setup/           - Circuit compilation CLI
pkg/api/             - HTTP router and server setup
pkg/circuits/        - Domain-specific circuit modules
primitives/          - Cryptographic primitives (GroupMath, MerkleProof, Commitment)
poseidon/            - Poseidon hash implementation
config/              - Configuration management
last_build/          - Compiled artifacts (Git LFS)
```

### Performance Notes
- Circuits load lazily on first request via `sync.Once`
- `sync.Pool` used for `big.Int` allocation to reduce GC pressure
- Server uses 10-minute read/write timeouts for proof generation
- GOMAXPROCS tuning recommended for production

### Known Technical Debt
- **Partial test coverage** - Primitives and every circuit family have honest-witness and forged-witness tests (`go test ./...`); handlers and `cmd/` have none
- **No structured logging** - Migrate from `fmt.Println` to slog with JSON output
- **No OpenTelemetry** - Add distributed tracing for production observability
- **Hard-coded config** - Move port and paths to environment variables
- **No interface abstractions** - Handlers use concrete types; refactor for testability
